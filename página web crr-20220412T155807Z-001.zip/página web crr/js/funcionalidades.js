function mostraralerta(){
	alert("vendemos el mejor caf� de colombia");
}